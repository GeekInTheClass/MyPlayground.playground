//#1번
//1~100 사이의 수 중에서 3의 배수이면서 동시에 5의 배수인 수의 합을 구하시오.
let intArray: [Int] = Array(1...100)
var sumAll: Int = 0

for item in intArray{
    if item%3 == 0 && item%5 == 0{
        sumAll += item
    }
}
print(sumAll)


//#2번
//1~1000 사이의 수를 모두 더하시오.
let intArray2: [Int] = Array(1...1000)
print(intArray2)
var sumAll2: Int = 0

for i in intArray2{
    sumAll2 += i
}

print(sumAll2)


//
var quiz1: [String] = ["one", "two", "three", "four"]
var aaaa: [String] = []

for item in quiz1{
    let item = item.uppercased()
    aaaa.append(item)
}

print(aaaa)